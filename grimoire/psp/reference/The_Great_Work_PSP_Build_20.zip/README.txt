The Great Work | PSP Build 20
Web release: great-work-deck-309461c7fc

Install
Copy PSP/GAME/GreatWork from the ZIP into the PSP storage root.
If you have an older build installed, replace its EBOOT.PBP.

Controls
D-pad or analog stick: move focus
Cross: open actions, confirm, or draw during the free-draw phase
Square: inspect the full card art
Circle: go back, cancel a sacrifice, or decline a Ward
Triangle: turn options, change payment where indicated, or zoom in inspection
L/R: switch board sections
Start: pause, controls, and game rules

Play menus show each move once per orientation. Cross uses the
suggested Marks. Use Triangle when Payment appears to choose a
different combination. Confirm before discarding a Mystery.

A rival winning alignment prompts you at the start of your turn
and whenever you try to end your turn while that threat remains.
Unused Marks also prompt you before ending.

The element badge turns with the card. One triangle marks Modest,
two mark Major, and three form a larger triangle for Master.
The triangles point down when reversed. Locked cards show a
padlock and count as upright. Mythics use an orientation arrow.

Rules
Start each turn with two + and two - reusable Marks. A Mystery
drawn into your hand can be spent for its printed sign. To restore
a spent Mark, sacrifice one hand card the first time this turn
and two cards the second time.

Summon for 3 Marks (Modest), 2 (Major), or 1 (Master). Include
one + for upright or one - for reversed. Mythics play for free
in either orientation. Locked slots can be replaced by matching
cards of equal or higher tier. Mythics can also replace any card
in your own field.

Hex flips an unlocked rival card in either direction. A Ward
can block it. Bless turns your own reversed card upright and
locks it. You can hold one face-down Ward. Set a Mystery Ward
for one Mark. Study draws an extra card for one Mark. The Shelf
also offers a combined draw and play when you can afford it.

Hold all four elements facing the same way through a rival's
turn to win. End actions to check rivals' alignments, then take
one free draw and discard down to seven cards if needed.

The 90 card faces and shared back come from the live Grimoire
release. Four-player games use two spare counters.
See licenses/ for bundled components.
